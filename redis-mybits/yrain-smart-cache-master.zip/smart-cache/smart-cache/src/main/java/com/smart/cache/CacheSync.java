package com.smart.cache;

/**
 * CacheSync
 * -----------------------------------------------------------------------------------------------------------------------------------
 * 
 * @author YRain
 */
public interface CacheSync {

    public void sendCommand(Command command);

}
